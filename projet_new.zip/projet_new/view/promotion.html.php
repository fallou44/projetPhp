<div class="promotions">
		<h2>promotions</h2>
		<span>Promos * Liste</span>
</div>
	
	<div class="containe">

        <div class="dev">
                    <div class="promo">
                        <span>Liste Des Promotions <span class="un">(1)</span></span>
                    </div>
                    
                    <form action="" class="input">
                        <input type="text" placeholder="Recherche ici ..." class="text" name="search">
                        <!-- <img src="public/images/equipement.png" alt="" class="equipement"  width="5%" height="100%"> -->
                        <a href="#"> <button><i class="fa-solid fa-plus"></i>nouvel</button></a>
                        
                    </form>
	</div>

                        <table>
                                <thead>
                                    <tr>
                                        <th>Libelle</th>
                                        <th>DateDebut</th>
                                        <th>DateFin</th>
                                        <th>Actions</th>

                                    </tr>
                                </thead>
                                <tbody>
                                <?php  

                                    $promos = findPromotion();
                                    if (isset($_POST["search"])){
                                        $promos= recherche($_POST["search"]);
                                    }

                                $Promotion = findPromotion();
                                foreach($promos as $promo):  ?>
                                    <tr>
                                        <td><?=$promo['libelle'] ?> </td> 
                                        <td><?=$promo['dateDebut'] ?></td>
                                        <td><?=$promo['dateFin'] ?></td>
                                        <td><input type="checkbox" class="check" style="accent-color: #008f89;" ></td>
                                    </tr>
                                    <?php endforeach; ?>  
                                </tbody>
                    </table>
</div>
