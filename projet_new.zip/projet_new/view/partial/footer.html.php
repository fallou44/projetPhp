</section>
<footer class="footer" >
    &copy; Sonatel Academy
</footer>
<div class="fixed-icon">
    <i class="fa-solid fa-gear"></i>
</div>
</body>
</html>