
  <div class="logo">
    <img src="../public/images/sonatel.png" style="height: 60px; width: 129px;" alt="Logo_sonatel">
  </div>
  <div class="login-form">
    <h4>Email et Mot de Passe Requis</h4>
    <div class="form-group">
      <label for="email">Email Adress <span>*</span></label>
      <input type="email" id="email" placeholder="Enter email Address*" required>
    </div>
    <div class="form-group">
      <label for="password">Password <span>*</span></label>
      <input type="password" id="password" placeholder="Enter your password*" required>
    </div>
    <div class="form-group-checkbox">
      <div>
        <input type="checkbox" style="accent-color: #67b7af;;" id="remember-me">
        <label for="remember-me">Remember me</label>
      </div>
      <a href="#">Mot de passe Oublié?</a>
    </div>
    <div class="form-group">
      <button type="submit">
        <a href="/presence" style="list-style: none; text-decoration: none; color: white;">Log in</a>
      </button>
    </div>
  </div>