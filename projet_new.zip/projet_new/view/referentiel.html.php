
			<div class="promotions">
				<h3>Référentiels</h3>
				<span>Référentiels * Création</span>
			</div>
			
<div class="referent">
					
			<div class="main">
						<?php 
								$refDig = findAllReferentiels();
								if (isset($_POST["search"])){
									$refDig= recherche($_POST["search"]);
								}


						$referentiel = findAllReferentiels();
						
								foreach($refDig as $referent) :  ?>

								<div class="img">
								<span class="points">
									<ul>
										<li></li>
										<li></li>
										<li></li>
									</ul>
								</span>
								<img src="<?= $referent['image'] ?>" alt="">
								<div class="ref">
									<span><?= $referent['nom'] ?></span> <br>
									<span class="active"><?= $referent['statut'] ?></span>
									
								</div>
							</div>
					
							<?php endforeach; ?>		
							
								
			</div>
			
			
			<div class="formRef" style="padding-right:22px ; padding-left:22px ;">
					<h4 style="font-size: 20px;" >Nouveau Référentiel</h4>
					<span style="font-size: 19px;">Libelle</span> <br>
		
					<!-- <i class="fa-regular fa-user" class="first-user"></i> -->
					<input type="text"  class="libelle"  placeholder=" entrer le Libelle"> <br>
					<!-- <i class="fa-regular fa-user" class="twon-user"></i> -->
					<textarea name="text" id="desc" cols="10" rows="5" placeholder="entrer la  descrition"></textarea>
					<button class="btn">Enregistrer</button>
			</div>
			
</div>
