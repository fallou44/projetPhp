<?php
    define("PATHPRESENCE", "data/presence.csv");
    define("PATHAPRENANT", "data/apprenant.csv");
    define("PATHPROMOTION", "data/promotion.csv");
    define("PATHREFERENTIEL", "data/referentiel.csv");
    SESSION_START();
