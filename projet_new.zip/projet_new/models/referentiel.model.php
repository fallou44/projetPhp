<?php 

    function findAllReferentiels(){

        // savefile(PATHREFERENTIEL, $referentiel);

        $referentiel = redCsv(PATHREFERENTIEL);
        

        return $referentiel;
    }



        // filtrer haut de  la page champ de recherche
        function recherche($search){
            $recherches=findAllReferentiels();
            $result=[];
        foreach($recherches as  $recherche ) {  

            if($recherche["nom"]==trim($search)){
                $result[]=$recherche;
            }       
        }  
        return $result;
        }

?>