<?php 

function findAllStudents(){
  

    // savefile(PATHAPRENANT, $student);

    $student = redCsv(PATHAPRENANT);

return $student;

}


//  filtrer  par email  
function recherche($filtrer){
    $recherches=findAllStudents();
    $result=[];
foreach($recherches as  $recherche ) {  

    if($recherche["nom"]==trim($filtrer)){
        $result[]=$recherche;
    }       
}  
return $result;
}

// fonction pagination
$eleByPage=4 ;
$pageEtu = isset($_GET['pageAff']) ? $_GET['pageAff'] : 1;
$totalPage=ceil(count(findAllStudents())/$eleByPage); //ceil() fonction qui arrondit par exee
// echo($pageEtu<1 || $pageEtu>$totalPage);
if($pageEtu<1 || $pageEtu>$totalPage)
header("Location:?page=$page&pageAff=1");
$eleDeb = ($pageEtu-1)*$eleByPage;
$etudiantsPage = array_slice(findAllStudents(), $eleDeb, $eleByPage);




$apprenants =findAllStudents();
$apprenants = $etudiantsPage;
if (isset($_POST["search"])){
    $apprenants= recherche($_POST["search"]);
}





        


?>



